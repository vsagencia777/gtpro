<?php
require_once "topo.php";
 
?>
<div class="slim-mainpanel">
      <div class="container">
	   
		
		 
		
		
		
		 
		
		
		
		
		
		
		<div class="section-wrapper">
          <label class="section-title">COMPRAR SISTEMA</label>
          
          
          
          <div class="row">
            
			
			<div class="col-md">
              <div class="card card-body">
                
				
				
			   
			  
			  <center>
			   
                
              <img src="<?php print $row["qrcode"]; ?>" alt="" style="width: 150;">
                
              <h5>Efetue o pagamento para a Chave PIX CNPJ</h5>
			    <h4>51.128.855/0001-33</h4>
			  <div class="card card-body bg-primary tx-white bd-0">
                <div class="card-text" align="center"><h4>VALOR R$: 150,00</h4></div>
			  </div><!-- card -->
			  </center>
               
				
				
              </div><!-- card -->
            </div><!-- col -->
            
			
			<div class="col-md mg-t-20 mg-md-t-0">
               
				<h4>APÓS O PAGAMENTO</h4>
				<p>
				1. Ao confirmar o pagamento envie o comprovante para o desenvolvedor. (45)988080666<br/><br/>
				2. Informe seu <b>Nome e Email</b> para receber o script imediatamente<br/><br/>
				3. Na compra do sistema você recebe todo o código fonte do sistema, atualizações, suporte e instalação<br/><br/>
			    </p>
				
				
			 
				
				
				<div align="center"><a href="https://wa.me/5545988080666?text=Sistema+Financeiro+-+Compra+e+Suporte" target="_blank"> <button type="submit" class="btn btn-dark" name="cart">Falar com o Desenvolvedor</button> </a></div>
				
			 
 
              
            </div><!-- col -->
             
          </div><!-- row -->
        </div><!-- section-wrapper -->
   
    

	</div>
</div>

 


 
 
		 
    <script src="../lib/jquery/js/jquery.js"></script>
	
 
	
    
<script src="../js/slim.js"></script>	
  </body>
</html>
